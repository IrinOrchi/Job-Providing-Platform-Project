<?php
session_start();
include "../config/config.php";

if(isset($_POST['update_profile'])){
    $name = $_POST['name'];
    $address = $_POST['address'];
    $cell_no = $_POST['cell_no'];
    $birthday = $_POST['birthday'];

    $user_type = $_SESSION['user_type'];
    $user = $_SESSION['user'];
    $id= $user['id'];

    $sql = "";
    $sqli_in = "";
    if($user_type=="Company"){
        $sql = "UPDATE company SET name='$name', address='$address', cell_no='$cell_no', birthday='$birthday' WHERE id='$id'";
        $sql_in = "SELECT * FROM company WHERE id='$id'";
    }else{
        $sql = "UPDATE student SET name='$name', address='$address', cell_no='$cell_no', birthday='$birthday' WHERE id='$id'";
        $sql_in = "SELECT * FROM student WHERE id='$id'";
    }

    mysqli_query($db, $sql);

    $result = mysqli_query($db, $sql_in);
    $data = mysqli_fetch_assoc($result);

    $_SESSION['user'] = $data;

    header("Location: ../profile.php");

}

?>
