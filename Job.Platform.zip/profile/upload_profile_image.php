<?php
session_start();
include('../config/config.php');

if(isset($_POST['submit'])) {
    $user = $_SESSION['user'];
    $user_type = $_SESSION['user_type'];
    $id = $user['id'];



    $hex_string = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $image_id="";
    for($i=0; $i<6; $i++) {
        $image_id  .= $hex_string[rand(0,strlen($hex_string)-1)];
    }


    $target_dir = "../images/";
    $target_file = $target_dir . basename($_FILES["img"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
    $new_file = $target_dir . $image_id . "." . $imageFileType;

    $file_name = $image_id . "." . $imageFileType;
//    echo "Pass";
    // Check if image file is a actual image or fake image
    if(isset($_POST["submit"])) {
        $check = getimagesize($_FILES["img"]["tmp_name"]);
        if($check !== false) {
//             echo "File is an image - " . $check["mime"] . ".";
            $uploadOk = 1;
        } else {
//             echo "File is not an image.";
            $uploadOk = 0;
        }
    }
    // Check if file already exists
    if (file_exists($target_file)) {
//         echo "Sorry, file already exists.";
        $uploadOk = 0;
    }
    // Check file size
    if ($_FILES["img"]["size"] > 50000000) {
//         echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }
    // Allow certain file formats
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif" ) {
//         echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }
    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
//         echo "Sorry, your file was not uploaded.";
        // if everything is ok, try to upload file
    } else {
        if (move_uploaded_file($_FILES["img"]["tmp_name"], $new_file)) {

            if($user_type=="Company"){
                $sql = "UPDATE company SET dp='$file_name' WHERE id='$id'";
                $sql_in = "SELECT * FROM company WHERE id='$id'";
            }else if($user_type=="Admin"){
                $sql = "UPDATE admin SET dp='$file_name' WHERE id='$id'";
                $sql_in = "SELECT * FROM admin WHERE id='$id'";
            }else{
                $sql = "UPDATE student SET dp='$file_name' WHERE id='$id'";
                $sql_in = "SELECT * FROM student WHERE id='$id'";
            }

            mysqli_query($db, $sql);

            $result = mysqli_query($db, $sql_in);
            $data = mysqli_fetch_assoc($result);

            $_SESSION['user'] = $data;

        } else {
//             echo "Sorry, there was an error uploading your file.";
            // 	echo "not Uploaded";
        }
    }

    header("Location: ../profile.php");
}


?>