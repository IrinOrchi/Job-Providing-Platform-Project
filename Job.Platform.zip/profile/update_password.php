<?php
session_start();
include "../config/config.php";

if(isset($_POST['update_password'])){

    $user = $_SESSION['user'];
    $user_type = $_SESSION['user_type'];

    $oldPass = $_POST['old_pass'];
    $newPass = $_POST['new_pass'];

    if(md5($oldPass)==$user['password']){
        $pass = md5($newPass);
        $id = $user['id'];
        if($user_type=="Company"){
            $sql = "UPDATE company SET password='$pass' WHERE id='$id'";
            $sql_in = "SELECT * FROM company WHERE id='$id'";
        }else if($user_type=="Admin"){
            $sql = "UPDATE admin SET password='$pass' WHERE id='$id'";
            $sql_in = "SELECT * FROM admin WHERE id='$id'";
        }else{
            $sql = "UPDATE student SET password='$pass' WHERE id='$id'";
            $sql_in = "SELECT * FROM student WHERE id='$id'";
        }

        mysqli_query($db, $sql);

        $_SESSION['msg_log'] = "Password Changed";

        $result = mysqli_query($db, $sql_in);
        $data = mysqli_fetch_assoc($result);

        $_SESSION['user'] = $data;
    }else{
        $_SESSION['msg_log'] = "Old Password Incorrect";
    }

    header("Location: ../profile.php");

}