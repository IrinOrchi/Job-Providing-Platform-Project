<?php
include "../config/config.php";

if(isset($_POST['upload_job'])){

    $id = $_POST['id'];
    $designation = $_POST['designation'];
    $description = $_POST['description'];
    $vacancy = $_POST['vacancy'];
    $responsibilities = $_POST['responsibilities'];
    $requirements = $_POST['education'];
    $job_type = $_POST['type'];
    $experience = $_POST['experience'];
    $location = $_POST['location'];
    $salary = $_POST['salary'];
    $compensation = $_POST['benefits'];
    $deadline = $_POST['deadline'];

//    $sql = "INSERT INTO jobs (id, designation, description, vacancy, responsibilities, requirements, job_type, experience, location, salary, compensation, deadline) VALUES
//            (NULL, '$designation', '$description', '$vacancy', '$responsibilities', '$requirements', '$job_type', '$experience', '$location', '$salary', '$compensation', '$deadline')";
    $sql = "UPDATE jobs SET designation='$designation', description='$description', vacancy='$vacancy', 
                responsibilities='$responsibilities', requirements='$requirements', job_type='$job_type', experience='$experience', location='$location', 
                salary='$salary', compensation='$compensation', deadline='$deadline' WHERE id='$id'";
    mysqli_query($db, $sql);

    header("Location: ../update_job.php?id=$id");

}

?>
