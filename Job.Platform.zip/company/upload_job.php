<?php
session_start();
include "../config/config.php";

if(isset($_POST['upload_job'])){
    $designation = $_POST['designation'];
    $description = $_POST['description'];
    $vacancy = $_POST['vacancy'];
    $responsibilities = $_POST['responsibilities'];
    $requirements = $_POST['education'];
    $job_type = $_POST['type'];
    $experience = $_POST['experience'];
    $location = $_POST['location'];
    $salary = $_POST['salary'];
    $compensation = $_POST['benefits'];
    $deadline = $_POST['deadline'];

    $user = $_SESSION['user'];
    $id = $user['id'];

    $sql = "INSERT INTO jobs (id, designation, description, vacancy, responsibilities, requirements, job_type, experience, location, salary, compensation, deadline, job_by) VALUES
            (NULL, '$designation', '$description', '$vacancy', '$responsibilities', '$requirements', '$job_type', '$experience', '$location', '$salary', '$compensation', '$deadline', '$id')";
    mysqli_query($db, $sql);

    header("Location: ../dashboard.php");

}

?>
