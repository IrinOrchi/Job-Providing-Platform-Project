<?php
include "../config/config.php";
$response = array();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {


    $status = $_POST['status'];
    $id = $_POST['id'];
    $sql = "";

    $sql = "UPDATE apply SET status = '$status' WHERE id='$id'";

    if (mysqli_query($db, $sql)) {
        $response['status'] = true;

    } else {
        $response['status'] = false;

    }

    echo json_encode($response);
}else{
    $response['status'] = true;
    return json_encode($response);
}

?>