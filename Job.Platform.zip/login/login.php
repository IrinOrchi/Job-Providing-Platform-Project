<?php
session_start();
include "../config/config.php";

if(isset($_POST['login'])){

    $user_type = $_POST['user_type'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql="";
    $hasLogin = false;

    if($user_type=="Company"){
        $sql = "SELECT * FROM company WHERE username='$username'";
        $result = mysqli_query($db, $sql);
        if(mysqli_num_rows($result)==1){
            $data = mysqli_fetch_assoc($result);
            echo $data["password"];
            if(md5($password)==$data['password']){
                $_SESSION["user"] = $data;
                $_SESSION["user_type"] = $user_type;
                $hasLogin = true;

            }
            else{
                $_SESSION['msg_log'] = "Password Mismatch";
            }
        }else{
            $_SESSION['msg_log'] = "Login Failed";
        }
    }

    else if($user_type=="Student"){
        $sql = "SELECT * FROM student WHERE username='$username'";
        $result = mysqli_query($db, $sql);
        if(mysqli_num_rows($result)==1){
            $data = mysqli_fetch_assoc($result);

            if(md5($password)==$data['password']){
                $_SESSION["user"] = $data;
                $_SESSION["user_type"] = $user_type;
                $hasLogin = true;
            }
            else{
                $_SESSION['msg_log'] = "Password Mismatch";
            }
        }else{
            $_SESSION['msg_log'] = "User not Found";
        }
    }

    else if($user_type=="Admin"){
        $sql = "SELECT * FROM admin WHERE username='$username'";
        $result = mysqli_query($db, $sql);
        if(mysqli_num_rows($result)==1){
            $data = mysqli_fetch_assoc($result);
            if(md5($password)==$data['password']){
                $_SESSION["user"] = $data;
                $_SESSION["user_type"] = $user_type;
                $hasLogin = true;
                header("Location: ../dashboard.php");
            }
            else{
                $_SESSION['msg_log'] = "Password Mismatch";
            }
        }else{
            $_SESSION['msg_log'] = "User not Found";
        }
    }else{
        $_SESSION["msg_log"] = "Please select a user type";
    }


    if($hasLogin){
        header("Location: ../dashboard.php");
    }else{
        header("Location: ../index.php");
    }



}

?>
