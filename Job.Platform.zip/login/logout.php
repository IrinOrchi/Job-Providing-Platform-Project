<?php
session_start();
session_destroy();
$_SESSION["user"] ="";
$_SESSION["msg_log"] = "";


header("Location: ../index.php");
?>