<?php
session_start();
include "../config/config.php";

if(isset($_POST['register'])){

    $user_type = $_POST['user_type'];
    $name = $_POST['name'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql="";




    if($user_type=="Company"){
        $sql = "SELECT * FROM company WHERE email='$email' OR username='$username'";
        $result = mysqli_query($db, $sql);
        if(mysqli_num_rows($result)>=1){
            $_SESSION['msg_log'] = "Username or Email Already Exists as a ".$user_type;
        }
        else{
            $pass = md5($password);
            $sql = "INSERT INTO company (name, email, username, password) VALUES ('$name', '$email', '$username', '$pass')";
            if(mysqli_query($db, $sql)){
                $_SESSION['msg_log'] = "Registration Successul as a ".$user_type."<br>Please Login Now";
            }else{
                $_SESSION['msg_log'] = "Registration Failed. Please Try Again";
            }
        }

    }

    if($user_type=="Student"){
        $sql = "SELECT * FROM student WHERE email='$email' OR username='$username'";
        $result = mysqli_query($db, $sql);
        if(mysqli_num_rows($result)>=1){
            $_SESSION['msg_log'] = "Username or Email Already Exists as a ".$user_type;
        }
        else{
            $pass = md5($password);
            $sql = "INSERT INTO student (name, email, username, password) VALUES ('$name', '$email', '$username', '$pass')";
            if(mysqli_query($db, $sql)){
                $_SESSION['msg_log'] = "Registration Successul as a ".$user_type."<br>Please Login Now";
            }else{
                $_SESSION['msg_log'] = "Registration Failed. Please Try Again";
            }
        }

    }

    header("Location: ../register.php");




}

?>
