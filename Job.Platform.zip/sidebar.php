<?php
$user_type = $_SESSION['user_type'];
$user = $_SESSION['user'];

?>
<div class="scroll-sidebar">
    <!-- Sidebar navigation-->
    <nav class="sidebar-nav">
        <ul id="sidebarnav">
            <!-- User Profile-->
            <li class="sidebar-item pt-2">
                <a class="sidebar-link waves-effect waves-dark sidebar-link" href="dashboard.php"
                   aria-expanded="false">
                    <i class="far fa-clock" aria-hidden="true"></i>
                    <span class="hide-menu">Dashboard</span>
                </a>
            </li>
            <li class="sidebar-item">
                <a class="sidebar-link waves-effect waves-dark sidebar-link" href="profile.php"
                   aria-expanded="false">
                    <i class="fa fa-user" aria-hidden="true"></i>
                    <span class="hide-menu">Profile</span>
                </a>
            </li>

            <?php
            if($user_type == "Company"){

                ?>
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="joblist.php"
                       aria-expanded="false">
                        <i class="fas fa-briefcase"></i>
                        <span class="hide-menu">Job List</span>
                    </a>
                </li>
                <?php
            }
            ?>

            <?php
            if($user_type == "Admin"){

                ?>
                <li class="sidebar-item">
                    <a class="sidebar-link waves-effect waves-dark sidebar-link" href="joblist.php"
                       aria-expanded="false">
                        <i class="fas fa-briefcase"></i>
                        <span class="hide-menu">Job Applications</span>
                    </a>
                </li>
                <?php
            }
            ?>

            <li class="text-center p-20 upgrade-btn">
                <a href="login/logout.php"
                   class="btn d-grid btn-danger text-white">
                    Log Out</a>
            </li>

            <li class="text-center p-20 upgrade-btn">

            </li>

            <?php
            if($user_type != "Admin"){

                ?>
                <li class="text-center p-20 upgrade-btn">
                    <b>Verification Status</b><br>
                    <?php
                    if($user['status']=="approve"){

                        ?>
                        <b style="font-size: 14px" class="label label-info">Approved</b>
                        <?php
                    }elseif ($user['status']=="pending"){
                        ?>
                        <b style="font-size: 14px" class="label label-warning">Pending</b>
                        <?php
                    }else{
                        ?>
                        <b style="font-size: 14px" class="label label-danger">Denied</b>
                        <?php
                    }
                    ?>
                </li>
                <?php
            }else{
                ?>
                <li class="text-center p-20 upgrade-btn">
                    <b>Verification Status</b><br>
                    <b style="font-size: 14px" class="label label-info">Approved</b>
                </li>
            <?php
            }
            ?>


        </ul>

    </nav>
    <!-- End Sidebar navigation -->
</div>