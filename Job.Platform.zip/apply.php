<?php
session_start();
include "config/config.php";
try{
    $user = $_SESSION["user"];
    $msg_log = $_SESSION["msg_log"];
    $id = $_GET['id'];
    $user_id = $user['id'];
    $company = $_GET['com'];

    $sql = "SELECT * FROM jobs WHERE id ='$id'";
    $result =mysqli_query($db, $sql);
    $data = mysqli_fetch_assoc($result);

    $sql_a = "SELECT * FROM apply WHERE job_id='$id' AND applicant_id='$user_id'";
    $result_a = mysqli_query($db, $sql_a);
    $data_a = mysqli_fetch_assoc($result_a);
    $application_status="";
    if(mysqli_num_rows($result_a)==1){
        $application_status=$data_a['status'];
    }
}catch (Exception $e){

}
?>

<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords"
          content="">
    <meta name="description"
          content="">
    <meta name="robots" content="noindex,nofollow">
    <title>Apply For Job</title>
    <link rel="canonical" href="https://www.wrappixel.com/templates/ample-admin-lite/" />
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="plugins/images/favicon.png">
    <!-- Custom CSS -->
    <link href="css/style.min.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>
<!-- ============================================================== -->
<!-- Preloader - style you can find in spinners.css -->
<!-- ============================================================== -->
<div class="preloader">
    <div class="lds-ripple">
        <div class="lds-pos"></div>
        <div class="lds-pos"></div>
    </div>
</div>
<!-- ============================================================== -->
<!-- Main wrapper - style you can find in pages.scss -->
<!-- ============================================================== -->
<div id="main-wrapper" data-layout="vertical" data-navbarbg="skin5" data-sidebartype="full"
     data-sidebar-position="absolute" data-header-position="absolute" data-boxed-layout="full">
    <!-- ============================================================== -->
    <!-- Topbar header - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <header class="topbar" data-navbarbg="skin5">
        <nav class="navbar top-navbar navbar-expand-md navbar-dark">
            <div class="navbar-header" data-logobg="skin6">
                <!-- ============================================================== -->
                <!-- Logo -->
                <!-- ============================================================== -->
                <a class="navbar-brand" href="dashboard.php">
                    <!-- Logo icon -->
                    <b class="logo-icon">
                        <!-- Dark Logo icon -->
                        <img src="plugins/images/logo-icon.png" alt="homepage" />
                    </b>
                    <!--End Logo icon -->
                    <!-- Logo text -->
                    <span class="logo-text">
                            <!-- dark Logo text -->
                            <img src="plugins/images/logo-text.png" alt="homepage" />
                        </span>
                </a>
                <!-- ============================================================== -->
                <!-- End Logo -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- toggle and nav items -->
                <!-- ============================================================== -->
                <a class="nav-toggler waves-effect waves-light text-dark d-block d-md-none"
                   href="javascript:void(0)"><i class="ti-menu ti-close"></i></a>
            </div>
            <!-- ============================================================== -->
            <!-- End Logo -->
            <!-- ============================================================== -->
            <div class="navbar-collapse collapse" id="navbarSupportedContent" data-navbarbg="skin5">
                <ul class="navbar-nav d-none d-md-block d-lg-none">
                    <li class="nav-item">
                        <a class="nav-toggler nav-link waves-effect waves-light text-white"
                           href="javascript:void(0)"><i class="ti-menu ti-close"></i></a>
                    </li>
                </ul>
                <!-- ============================================================== -->
                <!-- Right side toggle and nav items -->
                <!-- ============================================================== -->
                <ul class="navbar-nav ms-auto d-flex align-items-center">

                    <!-- ============================================================== -->
                    <!-- Search -->
                    <!-- ============================================================== -->
                    <li class=" in">
                        <form role="search" class="app-search d-none d-md-block me-3">
                            <input type="text" placeholder="Search..." class="form-control mt-0">
                            <a href="" class="active">
                                <i class="fa fa-search"></i>
                            </a>
                        </form>
                    </li>
                    <!-- ============================================================== -->
                    <!-- User profile and search -->
                    <!-- ============================================================== -->
                    <li>
                        <a class="profile-pic" href="profile.php">
                            <img src="images/<?php echo $user['dp'] ?>" alt="user-img" style="border-radius: 50%; height: 36px; width: 36px"
                                 class="img-circle"><span class="text-white font-medium"><?php echo $user["name"] ?></span></a>
                    </li>
                    <!-- ============================================================== -->
                    <!-- User profile and search -->
                    <!-- ============================================================== -->
                </ul>
            </div>
        </nav>
    </header>
    <!-- ============================================================== -->
    <!-- End Topbar header -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Left Sidebar - style you can find in sidebar.scss  -->
    <!-- ============================================================== -->
    <aside class="left-sidebar" data-sidebarbg="skin6">
        <!-- Sidebar scroll-->
        <?php include "sidebar.php"?>
        <!-- End Sidebar scroll-->
    </aside>
    <!-- ============================================================== -->
    <!-- End Left Sidebar - style you can find in sidebar.scss  -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Page wrapper  -->
    <!-- ============================================================== -->
    <div class="page-wrapper">
        <!-- ============================================================== -->
        <!-- Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <div class="page-breadcrumb bg-white">
            <div class="row align-items-center">
                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                    <h4 class="page-title">Apply For Job</h4>
                </div>
                <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                    <div class="d-md-flex">
                        <ol class="breadcrumb ms-auto">
                            <li><a href="#" class="fw-normal">Apply</a></li>
                        </ol>

                    </div>
                </div>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- ============================================================== -->
        <!-- End Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Container fluid  -->
        <!-- ============================================================== -->
        <div class="container-fluid">
            <!-- ============================================================== -->
            <!-- Start Page Content -->
            <!-- ============================================================== -->
            <!-- Row -->
            <div class="row">
                <!-- Column -->

                <!-- Column -->
                <!-- Column -->
                <div class="col-lg-8 col-xlg-9 col-md-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12 col-sm-12">
                                    <h2 class="text-info"><?php echo $data['description'] ?></h2>
                                    <h5>at <b><?php echo $company ?></b></h5><br><br>

                                    <b>Job Description</b>
                                    <p><?php echo $data['description'] ?></p>
                                </div>

                                <div class="col-12 col-sm-12">
                                    <b>Vacancy</b>
                                    <p><?php echo $data['vacancy'] ?></p>
                                </div>

                                <div class="col-12 col-sm-12">
                                    <b>Responsibilities</b>
                                    <p><?php echo $data['responsibilities'] ?></p>
                                </div>

                                <div class="col-12 col-sm-12">
                                    <b>Educational Requirements</b>
                                    <p><?php echo $data['requirements'] ?></p>
                                </div>

                                <div class="col-12 col-sm-12">
                                    <b>Job Type</b>
                                    <p><?php echo $data['job_type'] ?></p>
                                </div>

                                <div class="col-12 col-sm-12">
                                    <b>Experience</b>
                                    <p><?php echo $data['experience'] ?></p>
                                </div>

                                <div class="col-12 col-sm-12">
                                    <b>Job Location</b>
                                    <p><?php echo $data['location'] ?></p>
                                </div>

                                <div class="col-12 col-sm-12">
                                    <b>Salary</b>
                                    <p>BDT: <?php echo $data['salary'] ?></p>
                                </div>

                                <div class="col-12 col-sm-12">
                                    <b>Compensation & Benefits</b>
                                    <p><?php echo $data['compensation'] ?></p>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-xlg-3 col-md-12">
                    <div class="row">

                        <div class="col-12 col-sm-12">
                            <div class="card">
                                <div class="card-body">
                                    <h4>Job Summary</h4>
                                    <p><b>Published On: </b> <?php echo $data['created_at'] ?></p>
                                    <p><b>Vacancy: </b> <?php echo $data['vacancy'] ?></p>
                                    <p><b>Job Type: </b> <?php echo $data['job_type'] ?></p>
                                    <p><b>Job Location: </b> <?php echo $data['location'] ?></p>
                                    <p><b>Salary: </b> <?php echo $data['salary'] ?></p>
                                    <p><b>Deadline: </b> <?php echo $data['deadline'] ?></p>

                                </div>
                            </div>
                        </div>

                        <?php
                        if($application_status==""){
                        $today = date("Y-m-d");
                        if($today<$data['deadline']){
                        ?>

                        <div class="col-12 col-sm-12">
                            <div class="card">
                                <div class="card-body">
                                    <form class="form-horizontal form-material" action="student/apply.php" method="POST">
                                        <div class="form-group mb-4">
                                            <div class="form-group w-100 ">
                                                <div class="col-sm-12">
                                                    <input name="id" type="text" value="<?php echo $id ?>" hidden>
                                                    <input name="com" type="text" value="<?php echo $company ?>" hidden>
                                                    <input style="color: white; border-radius: 20px" name="apply" class="btn btn-primary w-100"
                                                           type="submit" value="Apply For the Job">
                                                </div>
                                            </div>

                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <?php
                        }
                        }
                        ?>

                        <?php
                        if($application_status!=""){
                            $today = date("Y-m-d");
                            if($today<$data['deadline']){
                        ?>

                        <div class="col-12 col-sm-12">
                            <div class="card">
                                <div class="card-body">
                                    <form class="form-horizontal form-material" action="student/withdraw.php" method="POST">
                                        <div class="form-group mb-4">

                                            <div class="form-group w-100 ">
                                                <div class="col-sm-12">
                                                    <input name="id" type="text" value="<?php echo $id ?>" hidden>
                                                    <input name="com" type="text" value="<?php echo $company ?>" hidden>
                                                    <input style="color: white; border-radius: 20px" name="withdraw" class="btn btn-info w-100"
                                                           type="submit" value="Withdraw Application">
                                                </div>
                                            </div>

                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>

                        <?php
                            }

                            ?>

                            <div class="col-12 col-sm-12">
                                <div align="center" class="form-group mb-4">

                                    <div class="form-group w-100 ">
                                        <div class="col-sm-12">
                                            <h5><b>Application Status</b></h5>
                                            <?php
                                            if($application_status=="pending"){
                                                ?>
                                                <span style="font-size: 14px" class="label label-warning" >Pending</span>

                                                <?php
                                            }else if($application_status=="deny"){
                                                ?>
                                                <span style="font-size: 14px" class="label label-danger" >Denied</span>
                                                <?php
                                            }else{
                                                ?>
                                                <span style="font-size: 14px" class="label label-success" >Approved</span>
                                                <?php

                                            }
                                            ?>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        <?php
                        }
                        ?>

                        <div class="col-12 col-sm-12">
                            <div class="form-group mb-4">
                                <div align="center" class="col-12 col-sm-12">
                                    <span style="color: #c53be2"><b><?php echo $msg_log ?></b></span>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>


                <!-- Column -->
            </div>
            <!-- Row -->
            <!-- ============================================================== -->
            <!-- End PAge Content -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Right sidebar -->
            <!-- ============================================================== -->
            <!-- .right-sidebar -->
            <!-- ============================================================== -->
            <!-- End Right sidebar -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Container fluid  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- footer -->
        <!-- ============================================================== -->
        <footer class="footer text-center"> Copyright @ 2021
        </footer>
        <!-- ============================================================== -->
        <!-- End footer -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Page wrapper  -->
    <!-- ============================================================== -->
</div>

<?php
$_SESSION["msg_log"] = "";

?>
<!-- ============================================================== -->
<!-- End Wrapper -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- All Jquery -->
<!-- ============================================================== -->
<script src="plugins/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap tether Core JavaScript -->
<script src="bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/app-style-switcher.js"></script>
<!--Wave Effects -->
<script src="js/waves.js"></script>
<!--Menu sidebar -->
<script src="js/sidebarmenu.js"></script>
<!--Custom JavaScript -->
<script src="js/custom.js"></script>
</body>

</html>