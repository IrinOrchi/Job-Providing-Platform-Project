<?php
session_start();
include "../config/config.php";

if(isset($_POST['withdraw'])){

    $id = $_POST['id'];
    $user = $_SESSION['user'];
    $user_id= $user['id'];
    $com = $_POST['com'];

    $sql="";

    $sql = "DELETE FROM apply WHERE job_id='$id' AND applicant_id='$user_id'";
    if(mysqli_query($db, $sql)){
        $_SESSION['msg_log'] = "Successfully Withdrawn";
    }else{
        $_SESSION['msg_log'] = "Withdraw Failed";
    }

    header("Location: ../apply.php?id=$id&com=$com");




}

?>
