<?php
session_start();
include "../config/config.php";

if(isset($_POST['apply'])){

    $id = $_POST['id'];
    $user = $_SESSION['user'];
    $user_id= $user['id'];
    $com = $_POST['com'];

    $sql="";

    $sql = "INSERT INTO apply (job_id, applicant_id) VALUES ('$id', '$user_id')";
    if(mysqli_query($db, $sql)){
        $_SESSION['msg_log'] = "Successfully Applied";
    }else{
        $_SESSION['msg_log'] = "Application Failed";
    }

    header("Location: ../apply.php?id=$id&com=$com");




}

?>
